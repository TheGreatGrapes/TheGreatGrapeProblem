#include "confetti.h"

Confetti::Confetti(float x, float y, int _id)
    :Particle(x,y,_id)
{
}
