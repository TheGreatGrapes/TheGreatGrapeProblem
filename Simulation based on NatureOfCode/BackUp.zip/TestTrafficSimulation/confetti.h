#ifndef CONFETTI_H
#define CONFETTI_H
#include "particle.h"

class Confetti : public Particle
{
public:
    Confetti(float, float, int);
};

#endif // CONFETTI_H
